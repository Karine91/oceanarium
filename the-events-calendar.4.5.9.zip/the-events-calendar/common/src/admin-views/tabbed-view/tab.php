<?php
/**
 * The default template for a Tabbed View Tab
 */
